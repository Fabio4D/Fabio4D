<?php


    $DATA = "$dbname.$nomedb$TGBot->table_name";


$nomedb = "Autorizzati";
$comando = "/tabellaid";
$salvataggio = "/cef";
$msg = $TGBot->text;
$id = $TGBot->chat_id;


//  CREAZIONE TABELLA DATI VUOTA //
$bonsignore = 229748356;

// COMANDO CHE CREA LA TABELLA
if($TGBot->text == "/tabellaid" and $TGBot->chat_id == $bonsignore){

// CREDENZIALI PER LA CONNESSIONE
$servername = "localhost";
$username = "itetsturzo";
$password = "Fabio@2002";
$dbname = "my_itetsturzo";

//TENTA LA CONNESSIONE
try {
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// SETTA I PDO ERROR COSÌ INVIERÀ L'ERRORE TRAMITE MESSAGGIO SENNÒ NON SI CAPISCE PERCHÉ NON FUNZIONA
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// RIPETO IL NOME DEL DATABASE  PER CREARE LA QUERY DI CREAZIONE TABELLA
$dbname = "my_itetsturzo";

// $DATA È IL NOME DELLA TABELLA DA CREARE, IL NOME DATABASE SERVE SEMPRE MENTRE DOPO IL PUNTO POSSO DARE IL NOME CHE PIÙ MI PIACE
$DATA = "$dbname.$nomedb$TGBot->table_name";

// CONDIZIONI DELL' SQL PER COSTRUIRE LA TABELLA
$sql = "CREATE TABLE IF NOT EXISTS $DATA(
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            Userid INT(6)  
            );";

    // ESEGUO LA QUERY SQL PER CREARE LA TABELLA
    $conn->exec($sql);

// INVIO UN MESSAGGIO
$TGBot->sendMessage($TGBot->chat_id,"Table $DATA created successfully");

// FINE CREAZIONE TABELLA
    }

// SE C'È UN ERRORE LO VADO A GESTIRE
catch(PDOException $e)
    {

//  INVIO UN MESSAGGIO CON L'ERRORE
$TGBot->sendMessage($TGBot->chat_id,"$sql $e");

// FINE GESTIONE ERRORI
    }

// TERMINO LA CONNESSIONE AL SERVER
$conn = null;


}

/////  FINE CREAZIONE TABELLA DATI  VUOTA //

//$id = $userdata['id'];

//Proviamo con estrazione dati da mandare in chat col bot///


if($TGBot->text == "/freezecomando")
{



    $msg = $TGBot->text;
    
    $dbname = "my_itetsturzo";
    $DATA = "$dbname.$nomedb$TGBot->table_name";
	$userquery = $TGBot->mdb->prepare("INSERT INTO $DATA (Userid) VALUES ('$msg')");    
 	$userquery->execute([$msg]);
    $TGBot->sendMessage($id,"Id inserito nel database");
    
    

   } 
 
 
 
 
 
 
/*
if($TGBot->cbdata_text == "/autorizzati" or $TGBot->text == "/autorizzati" or $TGBot->text == "Autorizzati")
{
$q = $TGBot->mdb->prepare("SELECT * FROM $nomedb$TGBot->table_name");
$q->execute();
    $r = $q->fetchAll();
$risultati2 = json_encode($r,true);

foreach($r as $row) {   // quindi accedi ai dati con ad esempio
   $luoghetto = $row['Luogo'];
   $codicetto = $row['Codice'];
   $titoletto = $row['Titolo'];
   
    $TGBot->sendVideo($id,$codicetto);
   $TGBot->sendPhoto($id,$codicetto);
   $TGBot->sendDocument($id,$codiceetto);
   }*/

  
