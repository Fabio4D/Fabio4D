<?php

$msg = $TGBot->text;
$id = $TGBot->chat_id;
$bonsignore = "229748356";

if (stristr($TGBot->text, '/bot' ) and $id == $bonsignore)
{

	$explode = explode(" ",$msg,5);
    $token = $explode[1];
    $sito = $explode[2];
    $cartella = $explode[3];
    $keybot = $explode[4];
    
    $creare = "https://api.telegram.org/bot$token/setwebhook?url=https://$sito.altervista.org/$cartella/index.php?fpam=$keybot%26token=$token";
	$linkerrore = "http://$sito.altervista.org/$cartella/index.php?token=$token&fpam=$keybot";
	$TGBot->sendMessage($id,"Weebook");
	$TGBot->sendMessage($id,$creare);
    $TGBot->sendMessage($id,"Link per trovare errore");
	$TGBot->sendMessage($id,"$linkerrore");

	
}

