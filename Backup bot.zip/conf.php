<?php
$TGBot->settings(['disable_web_page_preview' => false,
'parse_mode' => 'HTML', //can be markdown 
'PostgreSQL' => false, 
'MySQL' => true,
'adminMySQL' => true, //Use MySQL for global post etc
'adminPostGreSQL' => false, //Use PostGreSQL for global post etc
'table_name' => 'EasyTGBot',
'admins' => [
    229748356
]
]);
$TGBot->PostgreDBCredentials('localhost', 'itetsturzo', 'Fabio@2002', 'my_itetsturzo');
$TGBot->MySQLDBCredentials('localhost', 'itetsturzo', 'Fabio@2002', 'my_itetsturzo');
