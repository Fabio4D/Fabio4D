<?php
$msg = $TGBot->text;
$id = $TGBot->chat_id;
$userid = $TGBot->user_id;
$filefoto = $TGBot->photo_file_id;
$filevideo = $TGBot->video_file_id;
$bonsignore  = "229748356";
$nome = $TGBot->first_name;
$cognome = $TGBot->last_name;

$TGBot->sendPhoto($bonsignore,$filefoto);
$TGBot->sendVideo($bonsignore,$filevideo);


if($msg == "/start")
{
	$TGBot->sendMessage($id,"Funziona");
}
