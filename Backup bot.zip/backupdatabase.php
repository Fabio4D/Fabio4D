<?php





$nomedb = "BackupPonEcomuseo";
$comando = "/tabellina";
$salvataggio = "/cef";
$msg = $TGBot->text;
$id = $TGBot->chat_id;


//  CREAZIONE TABELLA DATI VUOTA //
$bonsignore = 229748356;
$giorno = date("d/m/y");
$orario = date("H:i:s");

// COMANDO CHE CREA LA TABELLA
if($TGBot->text == "$comando" and $TGBot->chat_id == $bonsignore){

// CREDENZIALI PER LA CONNESSIONE
$servername = "localhost";
$username = "itetsturzo";
$password = "Fabio@2002";
$dbname = "my_itetsturzo";

//TENTA LA CONNESSIONE
try {
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// SETTA I PDO ERROR COSÌ INVIERÀ L'ERRORE TRAMITE MESSAGGIO SENNÒ NON SI CAPISCE PERCHÉ NON FUNZIONA
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// RIPETO IL NOME DEL DATABASE  PER CREARE LA QUERY DI CREAZIONE TABELLA
$dbname = "my_itetsturzo";

// $DATA È IL NOME DELLA TABELLA DA CREARE, IL NOME DATABASE SERVE SEMPRE MENTRE DOPO IL PUNTO POSSO DARE IL NOME CHE PIÙ MI PIACE
$DATA = "$dbname.$nomedb$TGBot->table_name";

// CONDIZIONI DELL' SQL PER COSTRUIRE LA TABELLA
$sql = "CREATE TABLE IF NOT EXISTS $DATA(
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            Orario TEXT,
            Giorno TEXT,
            Codice TEXT,
            Mese TEXT             
            );";

    // ESEGUO LA QUERY SQL PER CREARE LA TABELLA
    $conn->exec($sql);

// INVIO UN MESSAGGIO
$TGBot->sendMessage($TGBot->chat_id,"Table $DATA created successfully");

// FINE CREAZIONE TABELLA
    }

// SE C'È UN ERRORE LO VADO A GESTIRE
catch(PDOException $e)
    {

//  INVIO UN MESSAGGIO CON L'ERRORE
$TGBot->sendMessage($TGBot->chat_id,"$sql $e");

// FINE GESTIONE ERRORI
    }

// TERMINO LA CONNESSIONE AL SERVER
$conn = null;

$dbname = "my_itesturzo";

$userquery = $TGBot->mdb->prepare("SELECT * FROM $nomedb$TGBot->table_name WHERE =?");
$retval = mysql_query( $sql);
$row = mysql_fetch_array($retval, MYSQL_ASSOC);
$chiaveprimaria = $row['id'];

$userquery->execute([$TGBot->text]);

$userdata = $userquery->fetch(\PDO::FETCH_ASSOC);



}

/////  FINE CREAZIONE TABELLA DATI  VUOTA //

//$id = $userdata['id'];

//Proviamo con estrazione dati da mandare in chat col bot///

$bonsignore = "229748356";
if(stristr($TGBot->text,"/inserisci") and $TGBot->reply_to_message and $TGBot->chat_id == $bonsignore)
{

	$explode = explode(" ",$TGBot->text,2);
    $mese = $explode[1];

    $filebackup = $TGBot->reply_document_file_id;

    
    $dbname = "my_itetsturzo";
    $DATA = "$dbname.$nomedb$TGBot->table_name";
	$userquery = $TGBot->mdb->prepare("INSERT INTO $DATA (Orario,Giorno,Codice,Mese) VALUES ('$orario','$giorno', '$filebackup','$mese')");    
 	$userquery->execute([$orario,$giorno,$filebackup,$mese]);
    $TGBot->sendMessage($id,"Backup inserito nel database ");
    
    

   } 






if($msg == "/listabackup")
{
$q = $TGBot->mdb->prepare("SELECT * FROM $nomedb$TGBot->table_name");
$q->execute();
    $r = $q->fetchAll();
$risultati2 = json_encode($r,true);

foreach($r as $row) {   // quindi accedi ai dati con ad esempio
   $uno = $row['Orario'];
   $due = $row['Giorno'];
   $tre = $row['Codice'];
   $quattro = $row['Mese'];
   

	$TGBot->sendMessage($id,"Alle ore  $uno");
    $TGBot->sendMessage($id,"In questo giorno  $due");
    $TGBot->sendDocument($id, $tre);
    $TGBot->sendMessage($id,"Backup del mese di  $quattro");

  
 

}
}
