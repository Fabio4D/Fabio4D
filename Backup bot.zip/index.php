<?php
$bonsignore = "229748356";
$id = $TGBot->chat_id;
$msg = $TGBot->text;
$userid = $TGBot->user_id;
include 'TGBot.php';
$TGBot = new TGBot(file_get_contents("php://input"), 'apkhelp', $_GET['fpam'], $_GET['token']);
$TGBot->SecTest();
include 'conf.php';
include 'mysql.php';
include 'postgres.php';
include 'commands.php';
include 'backup.php';
include 'weebook.php';
include 'backupdatabase.php';
include 'autorizzati.php';
include 'proviamodb.php';

