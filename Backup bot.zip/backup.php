<?php

$bonsignore = "";
$gruppobackup = "";
if($msg == "/backup")
{

$today = date("d-m-Y_H-i-s"); 
$BackupFile = "Backup_$today-$BotName.zip";

if(!file_exists('data_ultimo_backup.txt'))file_put_contents('data_ultimo_backup.txt', '');
$file = (file('data_ultimo_backup.txt'));
$rid = reset($file);
$toRemove = "Backup_$rid-$BotName.zip";
if(file_exists("$toRemove"))unlink ("$toRemove");
if(file_exists("data_ultimo_backup.txt"))unlink ("data_ultimo_backup.txt");


if(!file_exists('data_ultimo_backup.txt'))file_put_contents('data_ultimo_backup.txt', '');
file_put_contents('data_ultimo_backup.txt', "$today");

$rootPath = realpath(""); 
$zip = new ZipArchive(); $zip->open("$BackupFile", ZipArchive::CREATE | ZipArchive::OVERWRITE); 
$files = new RecursiveIteratorIterator( new RecursiveDirectoryIterator($rootPath), RecursiveIteratorIterator::LEAVES_ONLY 
);

foreach ($files as $file)
{ 
if (!$file->isDir())
{ 
$filePath = $file->getRealPath(); $relativePath = substr($filePath, strlen($rootPath) + 1); 
$zip->addFile($filePath, $relativePath); 
}
}
$zip->close();

$zip = new ZipArchive;
if ($zip->open("$BackupFile") === TRUE) {
    $zip->deleteName("$BackupFile");
    $zip->close();
}
$document = new CURLFile(realpath($BackupFile));
$TGBot->sendDocument($id,$document);
//$TGBot->sendMessage($Admin1,"$SitoBot/$BackupFile");
}